vc_version = 2142
official = True
nightly = False
